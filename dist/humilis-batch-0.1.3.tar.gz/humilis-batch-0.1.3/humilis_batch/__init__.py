"""Humilis plug-in to deploy AWS Batch resources."""


__version__ = "0.1.3"
__author__ = "German Gomez-Herrero"
